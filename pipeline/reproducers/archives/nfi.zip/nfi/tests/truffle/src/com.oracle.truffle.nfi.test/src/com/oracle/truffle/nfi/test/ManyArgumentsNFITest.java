/*
 * Copyright (c) 2026, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * The Universal Permissive License (UPL), Version 1.0
 *
 * Subject to the condition set forth below, permission is hereby granted to any
 * person obtaining a copy of this software, associated documentation and/or
 * data (collectively the "Software"), free of charge and under any and all
 * copyright rights in the Software, and any and all patent rights owned or
 * freely licensable by each licensor hereunder covering either (i) the
 * unmodified Software as contributed to or provided by such licensor, or (ii)
 * the Larger Works (as defined below), to deal in both
 *
 * (a) the Software, and
 *
 * (b) any piece of software and/or hardware listed in the lrgrwrks.txt file if
 * one is included with the Software each a "Larger Work" to which the Software
 * is contributed by such licensors),
 *
 * without restriction, including without limitation the rights to copy, create
 * derivative works of, display, perform, and distribute the Software and make,
 * use, sell, offer for sale, import, export, have made, and have sold the
 * Software and the Larger Work(s), and to sublicense the foregoing rights on
 * either these or other terms.
 *
 * This license is subject to the following condition:
 *
 * The above copyright notice and either this complete permission notice or at a
 * minimum a reference to the UPL must be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.oracle.truffle.nfi.test;

import org.junit.Assert;
import org.junit.Test;

import com.oracle.truffle.api.interop.InteropException;

/**
 * Calls with many arguments. The Native Image backend keeps the argument pointers of calls with up
 * to 16 arguments in a stack buffer and allocates them for longer calls, so both sides of that
 * limit are checked. Calls with 32 and 33 long arguments also cross the primitive buffer limit.
 */
public class ManyArgumentsNFITest extends NFITest {

    private static void testSum(int count) throws InteropException {
        StringBuilder signature = new StringBuilder("(");
        Object[] args = new Object[count];
        long expected = 0;
        for (int i = 0; i < count; i++) {
            signature.append(i == 0 ? "sint64" : ", sint64");
            // A distinct bit per argument, so a dropped or garbled argument changes the sum.
            args[i] = 1L << i;
            expected += 1L << i;
        }
        signature.append("):sint64");
        Object function = lookupAndBind("sum_" + count + "_SINT64", signature.toString());
        Object result = UNCACHED_INTEROP.execute(function, args);
        Assert.assertEquals(expected, UNCACHED_INTEROP.asLong(result));
    }

    @Test
    public void testSixteenArguments() throws InteropException {
        testSum(16);
    }

    @Test
    public void testSeventeenArguments() throws InteropException {
        testSum(17);
    }

    @Test
    public void testThirtyTwoArguments() throws InteropException {
        testSum(32);
    }

    @Test
    public void testThirtyThreeArguments() throws InteropException {
        testSum(33);
    }
}
